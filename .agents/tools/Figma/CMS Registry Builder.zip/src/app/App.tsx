import { useState } from 'react';
import { FileUploader } from './components/FileUploader';
import { FileList, FileItem } from './components/FileList';
import { DualEditor } from './components/DualEditor';
import { RelationshipGraph } from './components/RelationshipGraph';
import { LinkDialog } from './components/LinkDialog';
import { LLMPanel } from './components/LLMPanel';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from './components/ui/resizable';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Database, FileText, Network, Brain, GitMerge, Layers, Activity } from 'lucide-react';
import { toast } from 'sonner';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<[string | null, string | null]>([null, null]);
  const [linkDialogOpen, setLinkDialogOpen] = useState(false);
  const [currentLinkFile, setCurrentLinkFile] = useState<string | null>(null);

  const handleFilesAdded = async (newFiles: File[]) => {
    const filePromises = newFiles.map(async (file) => {
      const content = await file.text();
      return {
        id: `${Date.now()}-${Math.random()}`,
        name: file.name,
        content,
        linkedTo: [],
        metadata: {},
      };
    });

    const parsedFiles = await Promise.all(filePromises);
    setFiles((prev) => [...prev, ...parsedFiles]);
    toast.success(`Added ${newFiles.length} file${newFiles.length !== 1 ? 's' : ''}`);
  };

  const handleSelectFile = (fileId: string, pane: 0 | 1) => {
    const newSelection: [string | null, string | null] = [...selectedFiles];
    newSelection[pane] = fileId;
    setSelectedFiles(newSelection);
    toast.info(`Opened in ${pane === 0 ? 'left' : 'right'} pane`);
  };

  const handleDeleteFile = (fileId: string) => {
    setFiles((prev) => {
      const filtered = prev.filter((f) => f.id !== fileId);
      return filtered.map((f) => ({
        ...f,
        linkedTo: f.linkedTo.filter((id) => id !== fileId),
      }));
    });

    setSelectedFiles((prev) => [
      prev[0] === fileId ? null : prev[0],
      prev[1] === fileId ? null : prev[1],
    ]);

    toast.success('File removed');
  };

  const handleContentChange = (fileId: string, content: string) => {
    setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, content } : f)));
  };

  const handleLinkFiles = (fileId: string) => {
    setCurrentLinkFile(fileId);
    setLinkDialogOpen(true);
  };

  const handleUpdateLinks = (fileId: string, linkedIds: string[]) => {
    setFiles((prev) => prev.map((f) => (f.id === fileId ? { ...f, linkedTo: linkedIds } : f)));
  };

  const handleUpdateMetadata = (fileId: string, key: string, value: string) => {
    setFiles((prev) =>
      prev.map((f) =>
        f.id === fileId ? { ...f, metadata: { ...f.metadata, [key]: value } } : f
      )
    );
    toast.success('Metadata saved');
  };

  const leftFile = files.find((f) => f.id === selectedFiles[0]) || null;
  const rightFile = files.find((f) => f.id === selectedFiles[1]) || null;
  const currentLinkFileObj = files.find((f) => f.id === currentLinkFile) || null;
  const totalLinks = files.reduce((acc, f) => acc + f.linkedTo.length, 0);

  return (
    <div
      className="h-screen flex flex-col overflow-hidden"
      style={{
        background: '#080b14',
        fontFamily: "'Inter', sans-serif",
      }}
    >
      <Toaster theme="dark" />

      {/* Header */}
      <header
        className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b"
        style={{
          background: 'linear-gradient(135deg, #0d1021 0%, #111428 100%)',
          borderColor: '#1e2340',
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="flex items-center justify-center w-9 h-9 rounded-lg"
            style={{
              background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
              boxShadow: '0 0 20px rgba(99,102,241,0.4)',
            }}
          >
            <GitMerge className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1
              className="text-base font-semibold tracking-tight"
              style={{ color: '#e2e8f0', fontFamily: "'Inter', sans-serif" }}
            >
              CMS Registry Builder
            </h1>
            <p className="text-xs" style={{ color: '#475569' }}>
              Reconcile · Link · Organize · Export
            </p>
          </div>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4">
          <StatPill icon={<Layers className="w-3.5 h-3.5" />} label="Files" value={files.length} color="#6366f1" />
          <StatPill icon={<Network className="w-3.5 h-3.5" />} label="Links" value={totalLinks} color="#06b6d4" />
          <StatPill
            icon={<Activity className="w-3.5 h-3.5" />}
            label="Active"
            value={[selectedFiles[0], selectedFiles[1]].filter(Boolean).length}
            color="#10b981"
          />
        </div>
      </header>

      {/* Main layout */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          {/* Left sidebar */}
          <ResizablePanel defaultSize={20} minSize={14} maxSize={28}>
            <div
              className="h-full flex flex-col border-r"
              style={{ background: '#0c0f1d', borderColor: '#1e2340' }}
            >
              {/* Sidebar header */}
              <div
                className="px-4 py-3 border-b flex items-center gap-2"
                style={{ borderColor: '#1e2340' }}
              >
                <FileText className="w-4 h-4" style={{ color: '#6366f1' }} />
                <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: '#64748b' }}>
                  Files
                </span>
                <span
                  className="ml-auto text-xs px-2 py-0.5 rounded-full font-mono"
                  style={{ background: '#1e2340', color: '#6366f1' }}
                >
                  {files.length}
                </span>
              </div>

              {/* Uploader */}
              <div className="px-3 py-3 border-b" style={{ borderColor: '#1e2340' }}>
                <FileUploader onFilesAdded={handleFilesAdded} />
              </div>

              {/* File list */}
              <div className="flex-1 overflow-hidden">
                <FileList
                  files={files}
                  selectedFiles={selectedFiles}
                  onSelectFile={handleSelectFile}
                  onDeleteFile={handleDeleteFile}
                  onLinkFiles={handleLinkFiles}
                />
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle
            style={{ background: '#1e2340', width: '1px' }}
          />

          {/* Center — Dual Editor */}
          <ResizablePanel defaultSize={52} minSize={30}>
            <DualEditor
              leftFile={leftFile}
              rightFile={rightFile}
              onContentChange={handleContentChange}
            />
          </ResizablePanel>

          <ResizableHandle
            style={{ background: '#1e2340', width: '1px' }}
          />

          {/* Right sidebar — Graph + LLM */}
          <ResizablePanel defaultSize={28} minSize={20}>
            <Tabs
              defaultValue="graph"
              className="h-full flex flex-col"
              style={{ background: '#0c0f1d' }}
            >
              <TabsList
                className="rounded-none border-b grid grid-cols-2 h-10 p-0"
                style={{ background: '#0c0f1d', borderColor: '#1e2340' }}
              >
                <TabsTrigger
                  value="graph"
                  className="rounded-none h-full text-xs font-medium flex items-center gap-1.5 data-[state=active]:border-b-2 data-[state=active]:border-indigo-500"
                  style={{ color: '#64748b' }}
                >
                  <Network className="w-3.5 h-3.5" />
                  Graph
                </TabsTrigger>
                <TabsTrigger
                  value="llm"
                  className="rounded-none h-full text-xs font-medium flex items-center gap-1.5 data-[state=active]:border-b-2 data-[state=active]:border-violet-500"
                  style={{ color: '#64748b' }}
                >
                  <Brain className="w-3.5 h-3.5" />
                  AI Assistant
                </TabsTrigger>
              </TabsList>

              <TabsContent value="graph" className="flex-1 m-0 overflow-hidden">
                <RelationshipGraph
                  files={files}
                  onFileClick={(fileId) => handleSelectFile(fileId, 0)}
                />
              </TabsContent>

              <TabsContent value="llm" className="flex-1 m-0 overflow-hidden">
                <LLMPanel files={files} />
              </TabsContent>
            </Tabs>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {/* Bottom status bar */}
      <div
        className="flex-shrink-0 flex items-center px-4 py-1.5 border-t gap-4"
        style={{ background: '#080b14', borderColor: '#1e2340' }}
      >
        <span className="text-xs" style={{ color: '#334155' }}>
          <span style={{ color: '#475569' }}>Left:</span>{' '}
          <span style={{ color: '#6366f1' }}>{leftFile ? leftFile.name : '—'}</span>
        </span>
        <span className="text-xs" style={{ color: '#334155' }}>|
        </span>
        <span className="text-xs" style={{ color: '#334155' }}>
          <span style={{ color: '#475569' }}>Right:</span>{' '}
          <span style={{ color: '#06b6d4' }}>{rightFile ? rightFile.name : '—'}</span>
        </span>
        <span className="ml-auto text-xs" style={{ color: '#334155' }}>
          CMS Registry v1.0
        </span>
      </div>

      <LinkDialog
        open={linkDialogOpen}
        onOpenChange={setLinkDialogOpen}
        currentFile={currentLinkFileObj}
        allFiles={files}
        onUpdateLinks={handleUpdateLinks}
        onUpdateMetadata={handleUpdateMetadata}
      />
    </div>
  );
}

function StatPill({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
      style={{ background: '#111428', border: `1px solid #1e2340` }}
    >
      <span style={{ color }}>{icon}</span>
      <span className="text-xs" style={{ color: '#475569' }}>
        {label}
      </span>
      <span className="text-xs font-semibold font-mono" style={{ color }}>
        {value}
      </span>
    </div>
  );
}
